package com.nitin.springbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class courseAPI {

	public static void main(String[] args) {
     SpringApplication.run(courseAPI.class, args);
	}

}
