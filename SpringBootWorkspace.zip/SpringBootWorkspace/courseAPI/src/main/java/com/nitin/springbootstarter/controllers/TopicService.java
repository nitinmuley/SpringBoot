package com.nitin.springbootstarter.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.nitin.topic.Topic;

//singloton business service for all contollers can use single instance

@Service
public class TopicService {

	
	private List<Topic> topics= new ArrayList<>(Arrays.asList(
			new Topic("12","java","java programming"),
			new Topic("13","C","C programming"),
			new Topic("14","python","Python programming")
			));
	
	
	public List<Topic> getAllTopics(){
		return topics;
	}
	
	public Topic getTopic(String id) {
		
		return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
	}

	public void addTopic(Topic topic) {
       topics.add(topic);
	}
	

	
}
